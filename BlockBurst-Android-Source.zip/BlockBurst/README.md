# Block Burst (Android)

Original offline 8×8 block puzzle game, made in Java for Android. Includes touch drag-and-drop, 3 random pieces, line clearing, combos, high-score persistence, and game-over/restart.

## Build and install
1. Open the `BlockBurst` folder in Android Studio (recent version supporting Android Gradle Plugin 8.7.3).
2. Allow Gradle sync and Android SDK 35 installation if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the APK under `app/build/outputs/apk/debug/app-debug.apk` and transfer it to your Android phone.
5. Open it on your phone and allow installation from that source if Android asks.

This is source code, not a precompiled APK. Requires Android Studio and an internet connection for the initial Gradle dependencies. No ads or permissions are required.

## Build without a PC (GitHub Actions)
Upload the contents of this project folder to a GitHub repository (including `.github/workflows/build-apk.yml`). Open the repository's Actions tab, choose **Build Android APK**, and select **Run workflow**. When complete, download the **BlockBurst-APK** artifact, unzip it on your phone, and install `app-debug.apk`. This requires a GitHub account and an Actions-enabled repository. The APK is signed with a development/debug key, not a release key.

## Build entirely from your phone (GitHub Actions)
Upload the *contents* of this BlockBurst folder to a GitHub repository (including the hidden `.github` folder). In the repository's Actions tab, choose **Build Android APK** > **Run workflow**. When the job finishes, open its run and download the **BlockBurst-Android-APK** artifact. Extract the ZIP and install `app-debug.apk` on Android. The APK is a debug build suitable for personal testing, not a Play Store release.
