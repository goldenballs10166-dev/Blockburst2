package com.example.blockburst;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) { super.onCreate(state); setContentView(new Game(this)); }
  static class Game extends View {
    final Paint p = new Paint(3); final Random rng = new Random();
    final int[][] board = new int[8][8];
    final int[][][] shapes = {
      {{0,0}}, {{0,0},{1,0}}, {{0,0},{1,0},{2,0}}, {{0,0},{0,1},{0,2}},
      {{0,0},{1,0},{0,1},{1,1}}, {{0,0},{1,0},{2,0},{1,1}},
      {{0,0},{0,1},{1,1}}, {{0,0},{1,0},{1,1}},
      {{0,0},{1,0},{2,0},{3,0}}, {{0,0},{0,1},{0,2},{0,3}},
      {{0,0},{1,0},{2,0},{0,1},{1,1},{2,1}},
      {{0,0},{1,0},{2,0},{0,1},{1,1},{2,1},{0,2},{1,2},{2,2}}
    };
    final int[] palette = {0xff38bdf8,0xffa78bfa,0xfffb7185,0xfffbbf24,0xff34d399,0xfff472b6};
    final int[] picks = new int[3], colors = new int[3];
    float cell, left, top, trayY, downX, downY, dragX, dragY;
    int active = -1, score = 0, best = 0, combo = 0; boolean over = false;
    Game(Context c) { super(c); best = c.getSharedPreferences("game",0).getInt("best",0); refill(); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
    void refill(){ for(int i=0;i<3;i++){ picks[i]=rng.nextInt(shapes.length); colors[i]=1+rng.nextInt(palette.length); } }
    void reset(){ for(int[] r:board)Arrays.fill(r,0); score=combo=0; over=false; refill(); invalidate(); }
    void paint(int color){p.setColor(color);p.setStyle(Paint.Style.FILL);p.setStrokeWidth(1);}
    void text(String s,float x,float y,float size,int color){paint(color);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(size);p.setTextAlign(Paint.Align.CENTER);getCanvas.drawText(s,x,y,p);}
    Canvas getCanvas; // assigned during draw
    @Override protected void onDraw(Canvas canvas){ super.onDraw(canvas); getCanvas=canvas;
      float w=getWidth(),h=getHeight(); canvas.drawColor(0xff0b1220);
      cell=Math.min((w-36)/8f,(h*.52f)/8f); left=(w-cell*8)/2; top=Math.max(105,h*.22f-cell*1.2f); trayY=Math.min(h-115,top+cell*8+95);
      text("BLOCK BURST",w/2,56,30,0xfff8fafc);
      text("SCORE  "+score+"      BEST  "+best,w/2,91,17,0xffcbd5e1);
      paint(0xff17243b);canvas.drawRoundRect(left-6,top-6,left+8*cell+6,top+8*cell+6,13,13,p);
      for(int y=0;y<8;y++)for(int x=0;x<8;x++) tile(canvas,left+x*cell,top+y*cell,cell,board[y][x]==0?0xff26354e:palette[board[y][x]-1]);
      text("DRAG A PIECE ONTO THE BOARD",w/2,trayY-35,14,0xff94a3b8);
      for(int i=0;i<3;i++)if(picks[i]>=0 && i!=active) drawPiece(canvas,i,w*(i+.5f)/3,trayY,Math.min(cell*.66f,w/16));
      if(active>=0){int[][] s=shapes[picks[active]];float sz=cell;float px=dragX-sz*(maxX(s)+1)/2;float py=dragY-sz*(maxY(s)+1)/2;
        int gx=Math.round((px-left)/cell),gy=Math.round((py-top)/cell);
        if(dragY<top+cell*8+cell*2){boolean ok=fits(s,gx,gy);for(int[] q:s)if(gx+q[0]>=0&&gx+q[0]<8&&gy+q[1]>=0&&gy+q[1]<8)tile(canvas,left+(gx+q[0])*cell,top+(gy+q[1])*cell,cell,ok?0xff6ee7b7:0xfffb7185);}
        drawPiece(canvas,active,dragX,dragY,cell);
      }
      if(over){paint(0xdd0b1220);canvas.drawRoundRect(left,top,left+cell*8,top+cell*8,15,15,p);text("GAME OVER",w/2,top+cell*3.6f,32,0xffffffff);text("TAP TO RESTART",w/2,top+cell*4.5f,19,0xff38bdf8);}
    }
    void tile(Canvas c,float x,float y,float sz,int color){paint(color);float gap=Math.max(2,sz*.055f);c.drawRoundRect(x+gap,y+gap,x+sz-gap,y+sz-gap,Math.max(4,sz*.13f),Math.max(4,sz*.13f),p);}
    int maxX(int[][] s){int m=0;for(int[] a:s)m=Math.max(m,a[0]);return m;} int maxY(int[][] s){int m=0;for(int[] a:s)m=Math.max(m,a[1]);return m;}
    void drawPiece(Canvas c,int i,float cx,float cy,float sz){int[][] s=shapes[picks[i]];float x=cx-(maxX(s)+1)*sz/2,y=cy-(maxY(s)+1)*sz/2;for(int[] a:s)tile(c,x+a[0]*sz,y+a[1]*sz,sz,palette[colors[i]-1]);}
    boolean fits(int[][] s,int x,int y){for(int[] a:s){int xx=x+a[0],yy=y+a[1];if(xx<0||xx>=8||yy<0||yy>=8||board[yy][xx]!=0)return false;}return true;}
    boolean canMove(){for(int k:picks)if(k>=0)for(int y=0;y<8;y++)for(int x=0;x<8;x++)if(fits(shapes[k],x,y))return true;return false;}
    void place(int idx,int x,int y){int[][] s=shapes[picks[idx]];if(!fits(s,x,y))return;for(int[] a:s)board[y+a[1]][x+a[0]]=colors[idx];score+=s.length;
      boolean[] rows=new boolean[8],cols=new boolean[8];int lines=0;
      for(int j=0;j<8;j++){boolean full=true;for(int i=0;i<8;i++)if(board[j][i]==0)full=false;if(full){rows[j]=true;lines++;}}
      for(int i=0;i<8;i++){boolean full=true;for(int j=0;j<8;j++)if(board[j][i]==0)full=false;if(full){cols[i]=true;lines++;}}
      for(int j=0;j<8;j++)for(int i=0;i<8;i++)if(rows[j]||cols[i])board[j][i]=0;
      if(lines>0){combo++;score+=lines*100*combo;}else combo=0;
      picks[idx]=-1;boolean empty=true;for(int k:picks)if(k>=0)empty=false;if(empty)refill();
      if(score>best){best=score;getContext().getSharedPreferences("game",0).edit().putInt("best",best).apply();}
      over=!canMove();invalidate();
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth();switch(e.getActionMasked()){
      case MotionEvent.ACTION_DOWN: if(over){reset();return true;} for(int i=0;i<3;i++)if(picks[i]>=0&&Math.abs(x-w*(i+.5f)/3)<w/6&&Math.abs(y-trayY)<70){active=i;dragX=x;dragY=y-cell*1.6f;invalidate();return true;}return true;
      case MotionEvent.ACTION_MOVE:if(active>=0){dragX=x;dragY=y-cell*1.6f;invalidate();}return true;
      case MotionEvent.ACTION_UP:if(active>=0){int[][] s=shapes[picks[active]];float px=x-cell*(maxX(s)+1)/2,py=y-cell*1.6f-cell*(maxY(s)+1)/2;int gx=Math.round((px-left)/cell),gy=Math.round((py-top)/cell);place(active,gx,gy);active=-1;invalidate();}return true;
      case MotionEvent.ACTION_CANCEL:active=-1;invalidate();return true;
    }return true;}
  }
}
