plugins { id("com.android.application") }
android { namespace = "com.example.blockburst"; compileSdk = 35
    defaultConfig { applicationId = "com.example.blockburst"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
